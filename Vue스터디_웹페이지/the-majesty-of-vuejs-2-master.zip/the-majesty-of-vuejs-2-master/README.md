# The Majesty of Vuejs 2

[![Book Cover](https://s3.amazonaws.com/titlepages.leanpub.com/vuejs2/large?1476162030)](https://leanpub.com/vuejs2)

This repo is for educational use.

It contains demo apis, homework solutions and the code examples of the book, [The Majesty of Vue.js 2](https://leanpub.com/vuejs2).

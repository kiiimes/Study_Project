<template>
  <div id="app">
    <img class="logo" src="./assets/logo.jpg" height="200">
    <h1>
      Welcome to Palet town!
    </h1>
    <!-- route outlet -->
    <router-view></router-view>
  </div>
</template>

<style>
.subtitle {
  color: #42b983;
}
</style>
